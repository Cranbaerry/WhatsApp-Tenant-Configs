DROP TABLE IF EXISTS `#__dt_whatsapp_tenants_configs`;
